<?php 
session_start();
include_once('myconnection.php');
if(isset($_POST['submit'])){
	
	$name = $_SESSION['myname'];
	$codec = $_SESSION['mycode'];
	$set = $_POST['sets'];
	$myans = array($a1 = $_POST['Q1'],
	$a2 = $_POST['Q2'],
	$a3 = $_POST['Q3'],
	$a4 = $_POST['Q4'],
	$a5 = $_POST['Q5'],
	$a6 = $_POST['Q6'],
	$a7 = $_POST['Q7'],
	$a8 = $_POST['Q8'],
	$a9 = $_POST['Q9'],
	$a10 = $_POST['Q10']);
	
	$answers = mysql_query("SELECT * FROM answer_key WHERE qset='$set'");
	$keys = mysql_fetch_array($answers);
	
	for($apple=0;$apple<10;$apple++){
	if($myans[$apple] == $keys[$apple+1]){ $score[$apple+1] = 2; }	else { $score[$apple+1] = 0; }	
	}
	$first = $score[1] + $score[2] + $score[3] + $score[4] + $score[5];
	$second = $score[6] + $score[7] + $score[8] + $score[9] + $score[10];
	$total = ((($first + $second)/20) * 30) + 70;
	
	$save_score = mysql_query("INSERT INTO exams (id, name, score, passcode) Values ('','$name','$total','$codec')");
	$change_validity = mysql_query("UPDATE codes set validity='0' WHERE passcode ='$codec'");
	if($change_validity && $save_score){
		header('location:gateway.php');
	}else{
		echo 'Error';
	}
}
?>