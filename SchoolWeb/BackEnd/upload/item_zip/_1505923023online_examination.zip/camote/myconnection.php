<?php
mysql_connect("localhost", "root", "")or
die("Could not connect: " . mysql_error());
mysql_select_db("olexam");
date_default_timezone_set('Asia/Manila');
?>
<?php 
function user_page_security(){
	$sid = $_SESSION['mycode'];
	$secure_pages = mysql_query("SELECT * From codes Where passcode = '$sid'");
	$check_point = mysql_fetch_array($secure_pages);
	if($check_point[3] == 0){
    header("location: gateway.php");
}
}
?>
